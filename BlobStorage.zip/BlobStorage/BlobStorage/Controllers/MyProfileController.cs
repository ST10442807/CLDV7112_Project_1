﻿using System;
using System.IO;
using Azure.Storage.Blobs;
using BlobStorage.Models;
using Microsoft.AspNetCore.Mvc;

namespace BlobStorage.Controllers
{
    public class MyProfileController : Controller
    {
        private string blobConnectionString = "DefaultEndpointsProtocol=https;AccountName=democldv7112;AccountKey=/qd4PC/vxot5BwiWg0CTDZcdPbeaY9kWV5lgZOyKlpyrnFWgwd5A4DZEhilAH62vgrySusmVy+g9+AStRNKIbw==;EndpointSuffix=core.windows.net";
        private string containerName = "containerblob01";

        public IActionResult CreateProfile()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult UploadFile(ProfileVM model)
        {
            try{
                var filename = GenerateFileName(model.myFile.FileName, model.myFile.FileName);
                var fileUrl = "";
                BlobContainerClient container = new BlobContainerClient(blobConnectionString, containerName);

                try
                {
                    BlobClient blob = container.GetBlobClient(filename);
                    using (Stream stream = model.myFile.OpenReadStream())
                    {
                        blob.Upload(stream);
                    }
                    fileUrl = blob.Uri.AbsoluteUri;
                }
                catch (Exception ex)
                {
                      
                }
                var result = fileUrl;
                return Ok(result);
            }
            catch (Exception ex)
            {
                return Ok();
            }
        }

        public string GenerateFileName(string fileName, string CustomerName)
        {
            try
            {
                string strFileName = string.Empty;
                string[] strName = fileName.Split('.');
                strFileName = CustomerName + DateTime.Now.ToUniversalTime().ToString("yyyyMMdd\\THHmmssfff") + "." + strFileName[strName.Length - 1];
                return strFileName;
            }
            catch (Exception ex)
            {
                return fileName;
            }
        }

    }
}
